import React from 'react';

import ArticalsTable from '../../components/articalsTable/ArticalsTable';



const Articles: React.FC = () => {

    return (
        <div style={{textAlign: 'center'}}>

            <ArticalsTable/>

        </div>
    );
};

export default Articles;